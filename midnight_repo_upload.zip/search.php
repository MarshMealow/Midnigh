<?php
session_start();
include 'db.php';

$message = "";
$sql = "SELECT * FROM cars WHERE 1=1";

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['search'])) {
    $make = $_GET['s-make'];
    $year = $_GET['s-year'];
    $min = $_GET['s-min'];
    $max = $_GET['s-max'];

    if (empty($make) && empty($year) && empty($min) && empty($max)) {
        $message = "Please enter at least one search option.";
    } else {
        if (!empty($make)) {
            $sql .= " AND model LIKE '%$make%'";
        }

        if (!empty($year)) {
            $sql .= " AND year = '$year'";
        }

        if (!empty($min)) {
            $sql .= " AND price >= '$min'";
        }

        if (!empty($max)) {
            $sql .= " AND price <= '$max'";
        }
    }
}

$result = mysqli_query($conn, $sql);
$count = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Search page -->
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Midnight Motors — Search</title>

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- main css file -->
  <link rel="stylesheet" href="css/style.css" />

  <!-- small css just for this page -->
  <style>
    /* two columns for results */
    .results-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 14px;
    }
    @media (max-width: 640px) {
      .results-grid { grid-template-columns: 1fr; }
    }
    /* number of results label */
    .results-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 14px;
    }
    .results-count {
      font-size: 0.78rem;
      color: var(--text-muted);
      background: var(--bg-card);
      border: 1px solid var(--border);
      padding: 3px 10px;
      border-radius: 20px;
    }
  </style>
</head>
<body>

  <!-- nav bar -->
  <!-- nav bar -->
<nav class="nav">
  <div class="nav__inner">
    <a href="index.php" class="nav__logo">MIDNIGHT <span>MOTORS</span></a>
    <ul class="nav__links">
      <li><a href="index.php" class="nav__link">Home</a></li>
      <li><a href="register.php" class="nav__link ">Register</a></li>
      <?php if (isset($_SESSION['seller_id'])) { ?>
      <li><a href="logout.php" class="nav__link">Logout</a></li>
      <?php } else { ?>
      <li><a href="login.php" class="nav__link">Login</a></li>
      <?php } ?>
      <li><a href="cars.php" class="nav__link">Cars for Sale</a></li>
      <li><a href="search.php" class="nav__link nav__link--active">Search</a></li>
      <li><a href="feedback.php" class="nav__link">Feedback</a></li>
    </ul>

    <button class="nav__hamburger" id="hamburger" aria-label="Open menu">
      <span></span><span></span><span></span>
    </button>
  </div>

  <ul class="nav__mobile" id="mobile-menu">
    <li><a href="index.php" class="nav__link">Home</a></li>
    <li><a href="register.php" class="nav__link">Register</a></li>
    <?php if (isset($_SESSION['seller_id'])) { ?>
      <li><a href="logout.php" class="nav__link">Logout</a></li>
      <?php } else { ?>
      <li><a href="login.php" class="nav__link">Login</a></li>
      <?php } ?>
    <li><a href="cars.php" class="nav__link">Cars for Sale</a></li>
    <li><a href="search.php" class="nav__link nav__link--active">Search</a></li>
    <li><a href="feedback.php" class="nav__link">Feedback</a></li>
  </ul>
</nav>
  <main>

    <!-- page banner -->
    <div class="banner" style="height:140px; background: linear-gradient(135deg, #0D1A2D 0%, #060D1A 100%);">
      <div class="banner__overlay">
        <h2 class="banner__title">Search Cars</h2>
      </div>
    </div>

    <div class="container">
      <div class="page-layout page-layout--sidebar">

        <!-- search filters -->
        <div style="margin-top: 32px;">
          <div class="page-header" style="margin-bottom: 20px;">
            <div class="page-header__badge">Find your car</div>
            <h1 class="page-header__title">Search</h1>
          </div>

          <!-- message area -->
          <?php if (!empty($message)) { ?>
            <p style="color:red; font-weight:bold;"><?php echo $message; ?></p>
          <?php } ?>

          <div class="filter-card">
            <div class="filter-card__title">Filter by</div>

            <form class="form" method="GET" action="search.php" novalidate>
              <div class="form__group">
                <label class="form__label" for="s-make">Make / Model</label>
                <input class="form__input" type="text" id="s-make" name="s-make" placeholder="e.g. Toyota Camry" />
              </div>

              <div class="form__group">
                <label class="form__label" for="s-year">Year</label>
                <select class="form__select" id="s-year" name="s-year">
                  <option value="">Any year</option>
                  <option>2024</option><option>2023</option><option>2022</option>
                  <option>2021</option><option>2020</option><option>2019</option>
                  <option>2018</option><option>2017</option><option>2016</option>
                </select>
              </div>

              <div class="form__group">
                <label class="form__label">Price range ($NZD)</label>
                <div class="form__row form__row--price-range">
                  <input class="form__input" type="text" id="s-min" name="s-min" placeholder="Min" />
                  <input class="form__input" type="text" id="s-max" name="s-max" placeholder="Max" />
                </div>
              </div>

              <div class="form__group">
                <label class="form__label" for="s-type">Body type</label>
                <select class="form__select" id="s-type" name="s-type">
                  <option value="">Any type</option>
                  <option>Sedan</option>
                  <option>Hatchback</option>
                  <option>SUV</option>
                  <option>Ute</option>
                  <option>Wagon</option>
                  <option>Coupe</option>
                </select>
              </div>

              <div class="form__group">
                <label class="form__label" for="s-km">Max mileage (km)</label>
                <input class="form__input" type="text" id="s-km" name="s-km" placeholder="e.g. 100000" />
              </div>

              <div class="form__actions" style="flex-direction: column;">
                <button type="submit" name="search" class="btn btn--primary btn--full">Search</button>
                <a href="search.php" class="btn btn--secondary btn--full" id="search-clear">Clear filters</a>
              </div>
            </form>
          </div>
        </div>

        <!-- search results -->
        <div style="margin-top: 32px;">
          <div class="results-header">
            <span class="section__title">Search results</span>
            <span class="results-count" id="results-count">
              <?php echo $count; ?> results found
            </span>
          </div>

          <!-- sort buttons -->
          <div class="sort" style="margin-bottom: 16px;">
            <button class="sort__chip sort__chip--active" data-search-sort="newest">Newest</button>
            <button class="sort__chip" data-search-sort="price-asc">Price &#8593;</button>
            <button class="sort__chip" data-search-sort="price-desc">Price &#8595;</button>
            <button class="sort__chip" data-search-sort="km-asc">Mileage &#8593;</button>
          </div>

          <div class="results-grid">
            <?php while ($car = mysqli_fetch_assoc($result)) { ?>
              <div class="card search-result">
                <div class="card__image">
                  <span class="card__badge card__badge--new">New</span>
                </div>

                <div class="card__body">
                  <div class="card__make">
                    <?php echo $car['model']; ?>
                  </div>

                  <div class="card__price">
                    $<?php echo number_format($car['price']); ?>
                  </div>

                  <div class="card__detail">
                    <?php echo $car['year']; ?> &middot;
                    <?php echo $car['description']; ?> &middot;
                    <?php echo $car['colour']; ?>
                  </div>

                  <div class="card__footer">
                    <span class="card__seller">Seller car listing</span>
                    <a href="feedback.php?car_id=<?php echo $car['car_id']; ?>" class="card__btn">Enquire</a>
                  </div>
                </div>
              </div>
            <?php } ?>
            
          </div>
        </div>

      </div>
    </div>

  </main>

  <!-- footer -->
  <footer class="footer">
    <div class="footer__wave-container">
      <div class="footer__road"></div>
      <div class="footer__car">
        <svg class="footer__car-svg" viewBox="0 0 100 44" fill="none">
          <rect x="8" y="20" width="84" height="16" rx="3" fill="#3B82F6" opacity="0.9"/>
          <path d="M28 20 L36 8 L64 8 L72 20 Z" fill="#3B82F6" opacity="0.9"/>
          <path d="M30 20 L36 10 L52 10 L52 20 Z" fill="#0A0A0F" opacity="0.6"/>
          <path d="M54 20 L54 10 L64 10 L70 20 Z" fill="#0A0A0F" opacity="0.6"/>
          <circle cx="26" cy="36" r="7" fill="#1E293B" stroke="#3B82F6" stroke-width="1.5"/>
          <circle cx="26" cy="36" r="3" fill="#3B82F6" opacity="0.5"/>
          <circle cx="74" cy="36" r="7" fill="#1E293B" stroke="#3B82F6" stroke-width="1.5"/>
          <circle cx="74" cy="36" r="3" fill="#3B82F6" opacity="0.5"/>
          <rect x="88" y="22" width="6" height="5" rx="1" fill="#EAB308" opacity="0.9"/>
          <rect x="6"  y="22" width="4" height="5" rx="1" fill="#EF4444" opacity="0.9"/>
        </svg>
      </div>
    </div>
    <div class="footer__content">
      <div class="footer__logo">MIDNIGHT <span>MOTORS</span></div>
      <div class="footer__links">
        <a href="#" class="footer__link">About</a>
        <a href="#" class="footer__link">Contact</a>
        <a href="#" class="footer__link">Privacy</a>
      </div>
      <div class="footer__copy">&copy; 2025 Midnight Motors. All rights reserved.</div>
    </div>
  </footer>

  <script src="js/script.js"></script>
</body>
</html>
